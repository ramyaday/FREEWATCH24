create extension if not exists pgcrypto;
create type campaign_status as enum ('Draft','Active','Paused','Completed','Expired','Under Review');
create table profiles (id uuid primary key references auth.users(id) on delete cascade, username text unique, display_name text, bio text default '', avatar_url text, preferred_platforms text[] default '{}', created_at timestamptz not null default now());
create table campaigns (id uuid primary key default gen_random_uuid(), user_id uuid not null references auth.users(id) on delete cascade, name text not null check(length(name) between 2 and 90), video_url text not null, platform text not null, description text default '', target_views bigint not null check(target_views > 0), duration_days int not null default 30 check(duration_days between 1 and 90), status campaign_status not null default 'Under Review', created_at timestamptz not null default now(), starts_at timestamptz, expires_at timestamptz, updated_at timestamptz not null default now());
create index campaigns_user_created_idx on campaigns(user_id,created_at desc);create index campaigns_status_idx on campaigns(status,expires_at);
create table campaign_links(id uuid primary key default gen_random_uuid(),campaign_id uuid not null references campaigns(id) on delete cascade,url text not null,created_at timestamptz default now());
create table campaign_events(id uuid primary key default gen_random_uuid(),campaign_id uuid not null references campaigns(id) on delete cascade,event_type text not null check(event_type in('impression','outbound_click','share','report')),occurred_at timestamptz not null default now(),referrer text,metadata jsonb default '{}');
create index campaign_events_campaign_time_idx on campaign_events(campaign_id,occurred_at desc);
create table platform_accounts(id uuid primary key default gen_random_uuid(),user_id uuid not null references auth.users(id) on delete cascade,platform text not null,external_account_id text,access_token_ref text,connected_at timestamptz default now());
create table analytics(id uuid primary key default gen_random_uuid(),campaign_id uuid not null references campaigns(id) on delete cascade,metric text not null,value numeric not null,is_verified boolean not null default false,source text,recorded_at timestamptz not null default now());
create table notifications(id uuid primary key default gen_random_uuid(),user_id uuid not null references auth.users(id) on delete cascade,title text not null,body text not null,read_at timestamptz,created_at timestamptz default now());
create table referrals(id uuid primary key default gen_random_uuid(),referrer_id uuid not null references auth.users(id) on delete cascade,code text unique not null,clicks int not null default 0,registrations int not null default 0,created_at timestamptz default now());
create table leaderboard_entries(id uuid primary key default gen_random_uuid(),user_id uuid not null references auth.users(id) on delete cascade,category text not null,score numeric not null default 0,period_start date not null,period_end date not null,unique(user_id,category,period_start));
create table reports(id uuid primary key default gen_random_uuid(),reporter_id uuid references auth.users(id) on delete set null,campaign_id uuid references campaigns(id) on delete cascade,reason text not null,details text default '',status text not null default 'Open',created_at timestamptz default now());
create table admin_users(user_id uuid primary key references auth.users(id) on delete cascade,role text not null check(role in('admin','moderator')),created_at timestamptz default now());
create table audit_logs(id uuid primary key default gen_random_uuid(),actor_id uuid references auth.users(id) on delete set null,action text not null,target_type text,target_id uuid,details jsonb default '{}',created_at timestamptz default now());
create table user_preferences(user_id uuid primary key references auth.users(id) on delete cascade,low_data_mode boolean not null default false,animations_enabled boolean not null default true,notifications jsonb not null default '{}',updated_at timestamptz default now());
-- Enforce at most three Active campaigns atomically, including concurrent requests.
create or replace function create_campaign_limited(p_user_id uuid,p_name text,p_video_url text,p_platform text,p_description text,p_target_views bigint,p_duration_days int)
returns setof campaigns language plpgsql security definer set search_path=public as $$
declare created campaigns;
begin
 if auth.uid() is distinct from p_user_id then raise exception 'NOT_AUTHORIZED'; end if;
 perform pg_advisory_xact_lock(hashtextextended(p_user_id::text,0));
 if (select count(*) from campaigns where user_id=p_user_id and status='Active') >= 3 then raise exception 'ACTIVE_CAMPAIGN_LIMIT'; end if;
 insert into campaigns(user_id,name,video_url,platform,description,target_views,duration_days,status,starts_at,expires_at)
 values(p_user_id,p_name,p_video_url,p_platform,p_description,p_target_views,p_duration_days,'Active',now(),now()+make_interval(days=>p_duration_days)) returning * into created;
 return next created;
end $$;
revoke all on function create_campaign_limited(uuid,text,text,text,text,bigint,int) from public;
grant execute on function create_campaign_limited(uuid,text,text,text,text,bigint,int) to authenticated;
-- RLS: users can only read/update their own non-admin data.
alter table profiles enable row level security;create policy "profiles public read" on profiles for select using(true);create policy "profile owner write" on profiles for all using(auth.uid()=id) with check(auth.uid()=id);
alter table campaigns enable row level security;create policy "campaign owner access" on campaigns for all using(auth.uid()=user_id) with check(auth.uid()=user_id);
alter table campaign_links enable row level security;create policy "campaign link owner access" on campaign_links for all using(exists(select 1 from campaigns c where c.id=campaign_id and c.user_id=auth.uid())) with check(exists(select 1 from campaigns c where c.id=campaign_id and c.user_id=auth.uid()));
alter table campaign_events enable row level security;create policy "campaign event owner read" on campaign_events for select using(exists(select 1 from campaigns c where c.id=campaign_id and c.user_id=auth.uid()));
alter table analytics enable row level security;create policy "analytics owner read" on analytics for select using(exists(select 1 from campaigns c where c.id=campaign_id and c.user_id=auth.uid()));
alter table notifications enable row level security;create policy "notification owner" on notifications for all using(auth.uid()=user_id) with check(auth.uid()=user_id);
alter table referrals enable row level security;create policy "referral owner" on referrals for all using(auth.uid()=referrer_id) with check(auth.uid()=referrer_id);
alter table leaderboard_entries enable row level security;create policy "leaderboard public read" on leaderboard_entries for select using(true);
alter table reports enable row level security;create policy "report owner insert" on reports for insert with check(auth.uid()=reporter_id);
alter table admin_users enable row level security;create policy "admin self read" on admin_users for select using(auth.uid()=user_id);
alter table audit_logs enable row level security;create policy "audit admin read" on audit_logs for select using(exists(select 1 from admin_users a where a.user_id=auth.uid()));
alter table user_preferences enable row level security;create policy "preference owner" on user_preferences for all using(auth.uid()=user_id) with check(auth.uid()=user_id);
