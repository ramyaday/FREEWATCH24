-- Re-activate campaigns under the same per-user lock used by campaign creation.
create or replace function set_campaign_status_limited(p_campaign_id uuid,p_status campaign_status)
returns setof campaigns language plpgsql security definer set search_path=public as $$
declare owner_id uuid; updated campaigns;
begin
 if auth.uid() is null then raise exception 'NOT_AUTHORIZED'; end if;
 select user_id into owner_id from campaigns where id=p_campaign_id;
 if owner_id is null or owner_id <> auth.uid() then raise exception 'NOT_AUTHORIZED'; end if;
 if p_status not in ('Active','Paused') then raise exception 'INVALID_STATUS'; end if;
 perform pg_advisory_xact_lock(hashtextextended(owner_id::text,0));
 if p_status='Active' and (select count(*) from campaigns where user_id=owner_id and status='Active' and id<>p_campaign_id)>=3 then raise exception 'ACTIVE_CAMPAIGN_LIMIT'; end if;
 update campaigns set status=p_status,updated_at=now(),starts_at=case when p_status='Active' then coalesce(starts_at,now()) else starts_at end where id=p_campaign_id returning * into updated;
 return next updated;
end $$;
revoke all on function set_campaign_status_limited(uuid,campaign_status) from public;
grant execute on function set_campaign_status_limited(uuid,campaign_status) to authenticated;
